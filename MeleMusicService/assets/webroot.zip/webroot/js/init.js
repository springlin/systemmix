var OB = {"choose_wifi":null};
var curr_wifi = {}; //点击当前的wifi
var curr_connect = {};//当前连接的wifi
$(function(){
		var link_type = new Array('PSK','WEP','EAP', 'WPA2','Open');
		var url ='http://'+location.host + '/nplus';
		
		//倒计时
		// type:1 , type:2 没有连接的wifi忘记
		function countdown(time, type){
			$('#ih').show();
			$("#connect_loading").show();
			var c_time = $("#c_time");
			c_time.text(time+'秒');
			var i = time;
			var s_id = setInterval(function(){
				i--;
				if (i == 0) {
					clearInterval(s_id);
					$("#connect_loading").hide();
					$('#wlan_list').empty();
					if (type == 1) {
							$.ajax({
							   type: "GET",
							   url: url,
							   data: "m=get_ssid",
							   cache:false,
							   timeout:3000,
							   error:function(){
									$('#ih').show();
									$("#net_info").show();
							   },
							   success: function(msg){
									$('#ih').hide();
									location.reload();	
							   }
							});
					} else if (type == 2) {
						$('#ih').hide();
						reflash();
					}	
				}
				c_time.text( i+ '秒');		
			}, 1000);
		}
		//居中
		function setFloatMarginLeft(){
			$(".float").each(function(){
				$(this).css('margin-left', '-'+$(this).width()/2 + 'px');
			});			
		}
		setFloatMarginLeft();
		$(window).bind('orientationchange', function() {
			setFloatMarginLeft();
		});  
		
		function reflash() {
			$("#footer").hide();
			$('#wlan_list').empty();
			$("#pre_loading").show();
			get_curr_connect();
			update_wifi_list();
		}
		
		//wifi信号强度
		function getleve(leve){
			if (leve == 3) {
				return '强';
			}
			if (leve == 2) {
				return '较强';
			}
			if (leve == 1) {
				return '一般';
			}
			if (leve == 0) {
				return '弱';
			}
			
		}
		
		
		//单击wifi
		$('.wlan').live('click', function() {
			$('.cw').hide();
			e = $(this).parent();
			var input = $("#tc_box");
			curr_wifi  = {"ssid":e.attr('name'), "isconfig":e.attr('config'), "security":e.attr('security'), 'level':e.attr('level'), no:e.attr('id')};
			//当前连接的wifi和点击连接的wifi是同一个
			if (curr_wifi.no == curr_connect.no) {
				
				return;
			}
			//配置过或开放的wifi，直接连接
			if (curr_wifi.isconfig == 'true' || curr_wifi.security == 'Open') {
				
				connect_wifi(curr_wifi);
				update_wifi_list();
			} else {
				$("#ssid_name").text(curr_wifi.ssid);
				$('#ih').css('display', 'block');
				input.show();
			}
			
		}); 
		
		//获取当前连接
		function get_curr_connect() {
			$.get(url, {m:'get_ssid', timestemp:(new Date()).valueOf()}, function(data){
				if (data != '') {
					data = $.parseJSON(data);
					$('#curr_name').html(data.ssid);
					curr_connect = data;
				}
			});
		}
		//获取wlan列表
		function update_wifi_list() {
			$.get(url, {m:'get_wifi_list', timestemp:(new Date()).valueOf()}, function(data){
				data = $.parseJSON(data);	
				if (data.length == 0) {
					alert('不存在WLAN');
				} else {
					$('#pre_loading').hide();
					var wlan_list = $("#wlan_list");
					wlan_list.empty();
					var len = data.length;
					for(var i = 0; i < len; i++ ) {
						var img = 'wifi_'; 
						var islock = (data[i].security != "Open") ? 'lock': 'open';
						img = img + islock+'_'+data[i].level+'.png';
						var class_font = '';
						var more_html = '<span class="more"><img src="images/more2.png"></span>';
						var gou_html  = '<span class="gou"></span>';
						var curr_color = '';
						more_html = '<span class="more" style="cursor:pointer"><img src="images/more1.png"></span>';
						if (curr_connect.ssid == data[i].ssid) {
							gou_html  = '<span class="gou"><img src="images/gou.png"></span>';
							curr_connect.no = 'wifi_' + i.toString();
							curr_color = 'style="color:#327cc9"';
						}
						var li = '<li id="wifi_'+i+'" name="' +
						data[i].ssid+'" config="'+data[i].isConfig+'" security="'+data[i].security+'" level="'+data[i].level+'">'+
						more_html + gou_html + '<a class="wlan" href="javascript:;" '+curr_color+'><img src="images/'+img+'" />'+data[i].ssid+'</a></li>'
						wlan_list.append(li);
					}
					$("#footer").show();
				}
			});
		}
		//连接wifi
		function connect_wifi(wifi) {
		$.post(url+'?m=config_wifi&timestemp='+(new Date()).valueOf(), 
			{"ssid":wifi.ssid, "security":wifi.security, "password":wifi.password}, function(data){
				data = $.parseJSON(data);
				if (data.result) {
				} else {
					get_curr_connect();
				}
				update_wifi_list();
				curr_wifi = null;
			});
			countdown(60, 1);
		}	
		//输入面板消失
		$('.wifi_button').click(function(){
			$(".tc_box").css('display', 'none');
		});
		
		
		//修改密码
		$("#modify_wifi").click(function(){
			$("#passwd_input").show();
		});
		
		$("#reflash").click(function(){
			reflash();
		});
		
		$("#sure").click(function(){
			curr_wifi.password = $.trim($("#password").val());
			if (curr_wifi.password == '') {
				$('.cw').html('密码不能为空!');
				$('.cw').show();
				return;
			}
			if (curr_wifi.security == 'WEP' && curr_wifi.password.length < 5) {
				$('.cw').html('密码长度不对!');
				$('.cw').show();
				return;
			}
			if ((curr_wifi.security == 'WPA2' ||  curr_wifi.security == 'WPA') && curr_wifi.password.length < 8) {
				$('.cw').html('密码长度不对!');
				$('.cw').show();
				return;
			}
			if ((curr_wifi.security == 'WPA2' ||  curr_wifi.security == 'WPA') && curr_wifi.password.length < 8) {
				$('.cw').html('密码长度不对!');
				$('.cw').show();
				return;
			}
			$("#tc_box").hide();
			connect_wifi(curr_wifi);
			
		});
		
		$("#cancel").click(function(){
			$('#tc_box').hide();
			$('#ih').hide();
		});
		
		$('.more').live('click', function(){
			e = $(this).parent();
			curr_wifi  = {"ssid":e.attr('name'), "isconfig":e.attr('config'), "security":e.attr('security'), 'level':e.attr('level'), no:e.attr('id')};
			if (curr_wifi.no == curr_connect.no) {
				$("#more_turnoff").show();
				$("#more_no_save").hide();
				$('#more_connect').hide();
			} else if(curr_wifi.isconfig == 'true'){
				$('#more_turnoff').hide();
				$("#more_connect").show();
				$("#more_no_save").show();
			} else  {
				$("#more_connect").show();
				$('#more_turnoff').hide();
				$("#more_no_save").hide();
			}
			$('#more_ssid').text(curr_wifi.ssid);
			$('#more_info').text('安全性 ' +curr_wifi.security + ' 信号强度 ' + getleve(curr_wifi.level));
			$('#ih').show();
			$('#more_box').show();
		});
		//连接wifi
		$('#more_connect').click(function(){
			$("#more_box").hide();
			$("#ih").hide();
			if (curr_wifi.isconfig == 'false' ) {
				var input = $("#tc_box");
				
				//配置过或开放的wifi，直接连接
				if (curr_wifi.security == 'Open') {
					connect_wifi(curr_wifi);
					update_wifi_list();
				} else {
					$("#ssid_name").text(curr_wifi.ssid);
					$('#ih').css('display', 'block');
					input.show();
				}
			} else {
				connect_wifi(curr_wifi);
			}
		});
		//断开wifi
		$('#more_turnoff').click(function(){
			$("#more_box").hide();
			$("#ih").hide();
			$.post(url+"?m=forget_wifi&timestemp="+(new Date()).valueOf(), {"ssid":curr_wifi.ssid, 'security':curr_wifi.security}, function(data){
			});
			countdown(60, 1);
		});
		//取消
		$("#more_cancel").click(function(){
			$("#more_box").hide();
			$('#ih').hide();
		});
		$("#more_no_save").click(function(){
			$("#more_box").hide();
			$("#ih").hide();
			$.post(url+"?m=forget_wifi&timestemp="+(new Date()).valueOf(), {"ssid":curr_wifi.ssid, 'security':curr_wifi.security}, function(data){
			});
			countdown(5, 2);
		});
		$('#net_error').click(function(){
			$('#net_info').hide();
			$('#ih').hide();
		});
		//初始化
		get_curr_connect();
		update_wifi_list();
		
});